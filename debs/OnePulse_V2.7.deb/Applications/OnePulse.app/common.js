if (self === top) {
        var antiClickjack = document.getElementById("antiClickjack");
        antiClickjack.parentNode.removeChild(antiClickjack);
} else {
        top.location = self.location;
}
	
function iOSVersion() {
    var appVersion = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
    var version = [parseInt(appVersion[1], 10), parseInt(appVersion[2], 10), parseInt(appVersion[3] || 0, 10)];
    if (version[0] >= 9) {
  	  return true;
    }
    else{
      return false;	
    }
}
var checkVersion = iOSVersion();


	
