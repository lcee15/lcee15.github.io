//
//  Clickstream_ios.h
//  Clickstream_ios
//
//  Created by Faisal Ikwal on 17/07/18.
//  Copyright © 2018 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Clickstream_ios.
FOUNDATION_EXPORT double Clickstream_iosVersionNumber;

//! Project version string for Clickstream_ios.
FOUNDATION_EXPORT const unsigned char Clickstream_iosVersionString[];

